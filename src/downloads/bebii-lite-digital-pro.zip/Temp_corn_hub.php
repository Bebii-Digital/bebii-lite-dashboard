<?php

// Menangani URL
$siteurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/";
$currurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// Mengambil data dari file LP berdasarkan session
$fil = isset($_SESSION['slugID']) ? 'lp' . $_SESSION['slugID'] . '.txt' : 'defaultfile.txt';
$data_lp = ambil_data_text($fil);
$data_lp = preg_replace('#<br\s*/?>#i', '', $data_lp);
$data_lps = explode("\n", $data_lp);
$data_lps = array_map('trim', $data_lps);

// Validasi data LP
$shortlink = isset($data_lps[0]) ? $data_lps[0] : '';
$deskripsi_artikel = isset($data_lps[3]) ? $data_lps[3] : '';
$auto_refresh = isset($data_lps[6]) ? $data_lps[6] : '';
$waktuRand = isset($data_lps[7]) ? $data_lps[7] : '';
$adsense = isset($data_lps[8]) ? $data_lps[8] : '';

// Mengambil dan mengacak judul LP
$data_judul_lp = ambil_data_text('judul_lp.txt');
$data_judul_lp = preg_replace('#<br\s*/?>#i', '', $data_judul_lp);
$data_judul_lp = explode("\n", $data_judul_lp);
$judul_lp = array_map('trim', $data_judul_lp);
shuffle($judul_lp);
$developer = isset($judul_lp[0]) ? $judul_lp[0] : 'Developer';

// Mengambil dan mengacak video
$data_video = ambil_data_text('video.txt');
$data_video = preg_replace('#<br\s*/?>#i', '', $data_video);
$data_video = explode("\n", $data_video);
$video = array_map('trim', $data_video);
shuffle($video);

// Ambil data gambar
$data_gambar = ambil_data_text('gambar.txt');
$data_gambar = preg_replace('#<br\s*/?>#i', '', $data_gambar);
$data_gambar = explode("\n", $data_gambar);
$gambar = array_map('trim', $data_gambar);
shuffle($gambar);

// Mengambil dan mengacak judul
$data_judul = ambil_data_text('list_judul.txt');
$data_judul = preg_replace('#<br\s*/?>#i', '', $data_judul);
$data_judul = explode("\n", $data_judul);
$judul = array_map('trim', $data_judul);
shuffle($judul);

// Mengambil data Adsense
$data_ads = ambil_data_text('adsense.txt');
$data_ads = preg_replace('#<br\s*/?>#i', '', $data_ads);
$data_ads = explode("\n", $data_ads);
$data_ads = array_map('trim', $data_ads);

// Validasi data Adsense
$ca_pub_id = isset($data_ads[0]) ? $data_ads[0] : '';
$cx_code = isset($data_ads[1]) ? $data_ads[1] : '';
$ads_1 = isset($data_ads[2]) ? preg_replace('/\\\\/', '', $data_ads[2]) : '';
$ads_2 = isset($data_ads[3]) ? preg_replace('/\\\\/', '', $data_ads[3]) : '';
$opacity = isset($data_ads[4]) ? $data_ads[4] : 100;
$cse_width_1 = isset($data_ads[5]) ? $data_ads[5] : 300;
$cse_width_2 = isset($data_ads[6]) ? $data_ads[6] : 300;
$cse_top_1 = isset($data_ads[7]) ? $data_ads[7] : 100;
$cse_top_2 = isset($data_ads[8]) ? $data_ads[8] : 100;
$slot_width_1 = isset($data_ads[9]) ? $data_ads[9] : 300;
$slot_width_2 = isset($data_ads[10]) ? $data_ads[10] : 300;
$slot_top_1 = isset($data_ads[11]) ? $data_ads[11] : 100;
$slot_bottom_2 = isset($data_ads[12]) ? $data_ads[12] : 100;

if(isset($_SESSION['testing']) && $_SESSION['testing'] == true){
    $opacity = 70;
}

if(preg_match('/^off$/i', $adsense)){
    $iklan1 = '';
    $iklan2 = '';
}elseif(preg_match('/^cse$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:'.$cse_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$cse_width_1.'px;overflow:hidden;margin:auto">
    <style>.gsc-above-wrapper-area,.gsc-resultsbox-visible{display:none;}</style><gcse:searchresults-only gname="searchOnlyCSE_one" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
    $iklan2 = '<div class="isAds2" style="display:block;position:fixed;top:'.$cse_top_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$cse_width_2.'px;overflow:hidden;margin:auto">
    <gcse:searchresults-only gname="searchOnlyCSE_two" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
}elseif(preg_match('/^slot$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:'.$slot_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$slot_width_1.'px;height:100%;overflow:hidden;margin:auto">'.$ads_1.'</div></div>';
    $iklan2 = '<div class="isAds2" style="display:block;position:fixed;top:'.$slot_bottom_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$slot_width_2.'px;height:100%;overflow:hidden;margin:auto">'.$ads_2.'</div></div>';
}elseif(preg_match('/^infeed$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="height:100%;display:block;position:fixed;top:'.$infeed_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$infeed_width_1.'px;height:100%;overflow:hidden;margin:auto">'.$infeed_1.'</div></div>';
    $iklan2 = '<div class="isAds2" style="height:100%;display:block;position:fixed;top:'.$infeed_top_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$infeed_width_2.'px;height:100%;overflow:hidden;margin:auto">'.$infeed_2.'</div></div>';
}

// Mengambil data HPK
$data_hpk = ambil_data_text('hpk.txt');
$data_hpk = str_replace(['<br>', '<br/>', '<br />'], '', $data_hpk);
$hpk_keywordx = preg_split('#(\r\n?|\n)+#', $data_hpk);

// Validasi data HPK
shuffle($hpk_keywordx);
$csekey1 = isset($hpk_keywordx[0]) ? $hpk_keywordx[0] : '';
$csekey2 = isset($hpk_keywordx[1]) ? $hpk_keywordx[1] : '';

$timeplay = random_times();

$loadurl = $siteurl . $shortlink.'?load='.(isset($idmd5z) ? $idmd5z : '');

unset($_SESSION['slugID2']);
unset($_SESSION['slugLINK2']);
session_destroy();
?>
<!DOCTYPE html>
<html lang="en-US">
<head itemscope="itemscope" itemtype="http://schema.org/WebSite">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#9a1518" />
<title><?= get_the_title(); ?></title>
<link href="//www.youtube.com" rel="preconnect dns-prefetch">
<link href="//pagead2.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//googleads.g.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//ad.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//i.ytimg.com" rel="preconnect dns-prefetch">
<link href="//www.gstatic.com" rel="preconnect dns-prefetch">
<link href="//www.google.com" rel="preconnect dns-prefetch">
<link href="//cse.google.com" rel="preconnect dns-prefetch">
<link href="//tpc.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//www.google-analytics.com" rel="preconnect dns-prefetch">
<link href="//yt3.ggpht.com" rel="preconnect dns-prefetch">
<link href="//cdn.jsdelivr.net" rel="preconnect dns-prefetch">
<link href="//fonts.gstatic.com" rel="preconnect dns-prefetch">
<link href="//adservice.google.com" rel="preconnect dns-prefetch">
<link href="//ajax.cloudflare.com" rel="preconnect dns-prefetch">
<link href="//www.googletagmanager.com" rel="preconnect dns-prefetch">
<link href="//partner.googleadservices.com" rel="preconnect dns-prefetch">
<link href="//www.googletagservices.com" rel="preconnect dns-prefetch">
<link href="//static.doubleclick.net" rel="preconnect dns-prefetch">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"/>

<!-- batas -->
<style>
@import url("https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"); .navbar-icon-top .navbar-nav .nav-link > .fa { position: relative; width: 36px; font-size: 24px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { font-size: 0.75rem; position: absolute; right: 0; font-family: sans-serif; } .navbar-icon-top .navbar-nav .nav-link > .fa { top: 3px; line-height: 12px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { top: -10px; } @media (min-width: 576px) { .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 768px) { .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 992px) { .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 1200px) { .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa > .badge { top: -7px; } }
body { background-color: #383838; }.cont_ads1{display:block;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);height:auto !important;opacity:<?php echo $opacity; ?>%;z-index:2;width:100%;} .img-drop{width:100%;background-position:center;background-size:cover;object-fit:cover;} .info-bar { padding: 0.3rem; margin: -0.1rem 0 0 0; background-color: #ffffff; box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23); } .info-word { font-size: 2.85rem; margin-top: 0.2rem; margin-bottom: 0.2rem; transition: 0.5s; } .info-word:hover { color: #306a86; } .islike{font-size: 1.85rem;} .play-btns{font-size:3rem;} .views { font-size: 0.9rem; padding-left: 0.5rem; display: inline; margin: 0; } .likes { font-size: 0.9rem; color: #a0903f; margin: 0; display: inline; } .likes-col { padding-left: 2rem; text-align: left; } .title { padding-left: 1rem; font-size: 2rem; } .info-row { padding: 0 0.5rem; text-align: center; } .fa, .fas { color: #55556c; } .fa-thumbs-up { color: #a0903f; } .fa-thumbs-up:hover { color: #877b3b; } a:hover { text-decoration: none; } @media screen and (min-width: 992px) {.play-btns{font-size:5rem;} .img-drop{height:490px;}.h2-rel{font-size: 1.5rem;} .col-lg-2 { padding: 10px 10px 5px 10px; padding-top:0px; } } @media screen and (max-device-width: 992px) { .h2-rel{font-size: 1.3rem;} .img-drop{height:390px;} .info-row { text-align: left; } } @media screen and (max-device-width: 576px) {.img-drop{height:190px;} .info-word { font-size: 1rem; } .likes, .views { font-size: 0.75rem; } .islike{font-size: 0.7rem;} .title { padding-left: 0rem; font-size: 1.15rem; } .likes-col { padding-left: 1rem; text-align: left; } .info-row { padding: 0 0.2rem; } }
.isAds { position: absolute; top: 0; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; } #isAdsC, #isAdsC2 { max-width: 500px; } @media screen and (max-width: 767px) { .isAds, .isAds2 { height: auto; position: relative; } #isAdsC, #isAdsC2 { position: static; top: auto; left: auto; right: auto; opacity: 1; max-width: 500px; } } .isAds2 { position: absolute; bottom: 0px; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; }
</style>
    
<style>
        :root {
            --base-color-root: #212529;
            --secondary-color-root: #ffa310;
            --gray-color-root: #B8B8B8;
            --warna-text: #FFFFFF;
        }

        body,
        html {
            background-color: var(--base-color-root) !important;
            overflow-x: hidden;
        }

        .pagination {
            --bs-pagination-color: white !important;
            --bs-pagination-bg: var(--base-color-root) !important;
            --bs-pagination-border-width: 1px !important;
            --bs-pagination-active-border-color: var(--secondary-color-root) !important;
            --bs-pagination-active-color: white !important;
            --bs-pagination-active-bg: var(--base-color-root) !important;
            --bs-pagination-border-color: transparent !important;
            --bs-pagination-disabled-border-color: transparent !important;
            --bs-pagination-disabled-color: gray !important;
            --bs-pagination-disabled-bg: var(--base-color-root) !important;
            --bs-pagination-hover-color: var(--secondary-color-root) !important;
            --bs-pagination-hover-bg: var(--base-color-root) !important;
            --bs-pagination-focus-color: var(--secondary-color-root) !important;
            --bs-pagination-focus-bg: var(--base-color-root) !important;
            --bs-pagination-focus-box-shadow: var(--secondary-color-root) !important;
        }
    </style>

<!-- batas -->

</head>
<body class="position-relative min-vh-100 d-flex flex-column" style="overflow-y: auto;">
<script>
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', () => {
        window.location.href = window.location.href;
    });
</script>

<div id="bungkus-iklan">
    <?php echo $iklan1; ?>
	<?php echo $iklan2; ?>
</div>

	<!-- awal code -->
    <nav class="navbar navbar-expand-lg bg-dark shadow">
        <div class="container-fluid px-3 py-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" viewBox="0 0 448 512">
                <path fill="var(--secondary-color-root)"
                    d="M0 96C0 78.3 14.3 64 32 64l384 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 128C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32l384 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 288c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32L32 448c-17.7 0-32-14.3-32-32s14.3-32 32-32l384 0c17.7 0 32 14.3 32 32z" />
            </svg>
            <?php $tigaHurufPertama = substr($developer, 0, 3); ?>
            <?php $hurufSelanjutnya = substr($developer, 3); ?>
            <h1 class="navbar-brand fw-bold py-0 my-0" style="font-size: 2rem;">
                <span class="text-white"><?= $tigaHurufPertama ?> </span><span class="text-dark mx-1 p-1 rounded-2"
                    style="background-color: var(--secondary-color-root);"><?= $hurufSelanjutnya ?></span>
            </h1>
            <div class="d-flex gap-3 justify-content-center align-items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" viewBox="0 0 512 512">
                    <path fill="var(--warna-text)"
                        d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
                </svg>
                <svg class="rounded-circle p-1" style="background-color: var(--warna-text);"
                    xmlns="http://www.w3.org/2000/svg" width="35px" height="35px" viewBox="0 0 448 512">
                    <path
                        d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z" />
                </svg>
            </div>
        </div>
    </nav>

    <section class="w-100 d-flex overflow-hidden --warna-text mt-3 ps-3 gap-2 text-nowrap text-white">
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            Gangbang
        </span>
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            Blowjob
        </span>
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            MILF
        </span>
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            Anal
        </span>
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            Hentai
        </span>
        <span class="fw-bold bg-dark px-3 py-2 rounded-5 border border-secondary">
            Mature
        </span>
    </section>

    <section class="w-100 d-flex flex-column flex-grow-1 mt-3">
		<div class="position-relative overflow-hidden">
			<span id="vid-utama" class="play-pause-btn w-100 h-100 position-absolute d-flex align-items-center justify-content-center" style="top: 0%; left: 0%;z-index: 1;">
			</span>
			<video width="100%" id="myVideo" class="myVideo" preload="none" playsinline controls muted autoplay>
				<source src="<?= $video[0] ?>" type="video/mp4">
				Your browser does not support the video tag.
			</video>
		</div>

			<script>
				// Define an array of colors
				const colorData = ["#ef3aa5", "#ff8906", "#b8c1ec", "#6246ea", "#ffd803"]; // Example colors
				const getRandomColor = () => colorData[Math.floor(Math.random() * colorData.length)];
				const randomColor = getRandomColor();
				document.documentElement.style.setProperty('--bebii-play-btn-color', randomColor);
				const playIcon = `<svg viewBox="0 0 48 48" width="45%" height="45%" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_1493_662)">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M44 24C44 35.0457 35.0457 44 24 44C12.9543 44 4 35.0457 4 24C4 12.9543 12.9543 4 24 4C35.0457 4 44 12.9543 44 24ZM26 20.5359L20 17.0718V24V30.9282L26 27.4641L32 24L26 20.5359Z" fill="var(--bebii-play-btn-color)"/>
                                    <path d="M20 17.0718L20.5 16.2058C20.1906 16.0271 19.8094 16.0271 19.5 16.2058C19.1906 16.3844 19 16.7145 19 17.0718H20ZM20 30.9282H19C19 31.2854 19.1906 31.6156 19.5 31.7942C19.8094 31.9728 20.1906 31.9728 20.5 31.7942L20 30.9282ZM32 24L32.5 24.866C32.8094 24.6874 33 24.3572 33 24C33 23.6427 32.8094 23.3126 32.5 23.134L32 24ZM24 45C35.598 45 45 35.598 45 24H43C43 34.4934 34.4934 43 24 43V45ZM3 24C3 35.598 12.402 45 24 45V43C13.5066 43 5 34.4934 5 24H3ZM24 3C12.402 3 3 12.402 3 24H5C5 13.5066 13.5066 5 24 5V3ZM45 24C45 12.402 35.598 3 24 3V5C34.4934 5 43 13.5066 43 24H45ZM19.5 17.9378L25.5 21.4019L26.5 19.6699L20.5 16.2058L19.5 17.9378ZM21 24V17.0718H19V24H21ZM21 30.9282V24H19V30.9282H21ZM25.5 26.5981L19.5 30.0622L20.5 31.7942L26.5 28.3301L25.5 26.5981ZM31.5 23.134L25.5 26.5981L26.5 28.3301L32.5 24.866L31.5 23.134ZM25.5 21.4019L31.5 24.866L32.5 23.134L26.5 19.6699L25.5 21.4019Z" fill="var(--bebii-play-btn-color)"/>
                                </g>
                            </svg>
                            `;
                document.addEventListener('DOMContentLoaded', (event) => {
					const video = document.getElementById('myVideo');
					const vidUtama = document.getElementById("vid-utama");
					let hasPaused = false;
					const playPauseBtn = document.querySelectorAll('.play-pause-btn');

					playPauseBtn.forEach(btn => {
						btn.innerHTML = playIcon;
					});

					video.addEventListener('play', () => {
						if (!hasPaused) {
							const randomTime = <?= $waktuRand ?> * 1000;
						vidUtama.innerHTML = "";
						setTimeout(() => {
							video.pause();
							vidUtama.innerHTML = playIcon;
							hasPaused = true;
						}, randomTime);
						}
					});

					vidUtama.addEventListener('click', () => {
						if (video.paused) {
							video.play();
							vidUtama.innerHTML = "";
						} else{
							video.pause();
							vidUtama.innerHTML = playIcon;
						}
					});
				});
			</script>

		
		<div class="container p-2">
                <div class="d-flex justify-content-between">
                    <div class="d-flex align-items-center">						
                        <span class="pe-2" style="color: var(--warna-text);"><?= $judul[0] ?></span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="rgba(13,110,253)">
                            <path d="M0 0h24v24H0V0z" fill="none">
                            </path>
                            
                        </svg>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="d-flex align-items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="var(--warna-text)" viewBox="0 0 16 16">
                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"></path>
                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"></path>
                            </svg>
                            <span style="color: var(--warna-text);">
                                <script>
                                    var randomValue = Math.floor(Math.random() * 100) + 1;
                                    var randomValue2 = Math.floor(Math.random() * 10) + 1;
                                    document.write(randomValue + "." + randomValue2 + "M");
                                </script>
                            </span>
                        </div>
                        <div class="d-flex align-items-center gap-1">
                            <svg viewBox="0 0 24 24" width="16px" height="16px" fill="var(--warna-text)" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2 8.99997H5V21H2C1.44772 21 1 20.5523 1 20V9.99997C1 9.44769 1.44772 8.99997 2 8.99997ZM7.29289 7.70708L13.6934 1.30661C13.8693 1.13066 14.1479 1.11087 14.3469 1.26016L15.1995 1.8996C15.6842 2.26312 15.9026 2.88253 15.7531 3.46966L14.5998 7.99997H21C22.1046 7.99997 23 8.8954 23 9.99997V12.1043C23 12.3656 22.9488 12.6243 22.8494 12.8658L19.755 20.3807C19.6007 20.7554 19.2355 21 18.8303 21H8C7.44772 21 7 20.5523 7 20V8.41419C7 8.14897 7.10536 7.89462 7.29289 7.70708Z">
                            </path>
                            </svg>
                            <span style="color: var(--warna-text);">
                                <script>
                                    var randomValue = Math.floor(Math.random() * 100) + 1;
                                    document.write(randomValue + "%");
                                </script>
                            </span>
                        </div>
                    </div>
                </div>

            </div>
		
		<?php 
			for ($i=0; $i < 6; $i++) {
                shuffle($judul);
                shuffle($gambar);
		?>
        <!-- Content Loop -->
        <div class="d-flex w-100 flex-column">
            <div class="position-relative">
                <svg class="position-absolute start-50 bottom-50 rounded-circle border-white border-3 border py-1 ps-1" style="margin-left: -20px;margin-bottom: -20px;" xmlns="http://www.w3.org/2000/svg" width="2.5rem" height="2.5rem" viewBox="0 0 384 512">
                    <path fill="white" d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/>
                </svg>
                <span class="position-absolute bottom-0 end-0 m-2 px-2 rounded-2 bg-secondary --warna-text">
                     <script>
                        var randomTime = Math.floor(Math.random() * 60) + 1;
                        var randomTime2 = Math.floor(Math.random() * 60) + 1;
                        document.write(randomTime + ":" + randomTime2);
                     </script>
                </span>
                <img class="w-100" src="<?= $gambar[0] ?>" alt="" style="object-fit: cover;height: 180px;">
            </div>
            <div class="container p-2">
                <div class="d-flex justify-content-between">
                    <div class="d-flex align-items-center">						
                        <span class="pe-2" style="color: var(--warna-text);"><?= $judul[0] ?></span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="rgba(13,110,253)">
                            <path d="M0 0h24v24H0V0z" fill="none">
                            </path>
                            
                        </svg>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="d-flex align-items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="var(--warna-text)" viewBox="0 0 16 16">
                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"></path>
                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"></path>
                            </svg>
                            <span style="color: var(--warna-text);">
                                <script>
                                    var randomValue = Math.floor(Math.random() * 100) + 1;
                                    var randomValue2 = Math.floor(Math.random() * 10) + 1;
                                    document.write(randomValue + "." + randomValue2 + "M");
                                </script>
                            </span>
                        </div>
                        <div class="d-flex align-items-center gap-1">
                            <svg viewBox="0 0 24 24" width="16px" height="16px" fill="var(--warna-text)" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2 8.99997H5V21H2C1.44772 21 1 20.5523 1 20V9.99997C1 9.44769 1.44772 8.99997 2 8.99997ZM7.29289 7.70708L13.6934 1.30661C13.8693 1.13066 14.1479 1.11087 14.3469 1.26016L15.1995 1.8996C15.6842 2.26312 15.9026 2.88253 15.7531 3.46966L14.5998 7.99997H21C22.1046 7.99997 23 8.8954 23 9.99997V12.1043C23 12.3656 22.9488 12.6243 22.8494 12.8658L19.755 20.3807C19.6007 20.7554 19.2355 21 18.8303 21H8C7.44772 21 7 20.5523 7 20V8.41419C7 8.14897 7.10536 7.89462 7.29289 7.70708Z">
                            </path>
                            </svg>
                            <span style="color: var(--warna-text);">
                                <script>
                                    var randomValue = Math.floor(Math.random() * 100) + 1;
                                    document.write(randomValue + "%");
                                </script>
                            </span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
		<?php } ?>
        <!-- End Content Loop -->

    </section>
    
    <!-- Pagination -->
    <section class="container container-fluid justify-content-center d-flex pt-4">
        <nav aria-label="...">
        <ul class="pagination">
            <li class="page-item disabled">
            <span class="page-link">Previous</span>
            </li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
            <li class="page-item"><a class="page-link" href="#">2154</a></li>
            <li class="page-item">
            <a class="page-link" href="#">Next</a>
            </li>
        </ul>
        </nav>
    </section>
    <!-- Pagination End -->

    <!-- Footer -->
    <footer class="py-3 mt-4 bg-dark">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3 gap-4">
            <li class="nav-item">
                <svg class="rounded-circle bg-secondary p-1" width="25px" height="25px" fill="black" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z">
                    </path>
                </svg>
            </li>
            <li class="nav-item">
                <svg class="rounded-circle bg-secondary p-1" viewBox="0 0 24 24" width="27px" height="27px" fill="black" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19.3034 5.33716C17.9344 4.71103 16.4805 4.2547 14.9629 4C14.7719 4.32899 14.5596 4.77471 14.411 5.12492C12.7969 4.89144 11.1944 4.89144 9.60255 5.12492C9.45397 4.77471 9.2311 4.32899 9.05068 4C7.52251 4.2547 6.06861 4.71103 4.70915 5.33716C1.96053 9.39111 1.21766 13.3495 1.5891 17.2549C3.41443 18.5815 5.17612 19.388 6.90701 19.9187C7.33151 19.3456 7.71356 18.73 8.04255 18.0827C7.41641 17.8492 6.82211 17.5627 6.24904 17.2231C6.39762 17.117 6.5462 17.0003 6.68416 16.8835C10.1438 18.4648 13.8911 18.4648 17.3082 16.8835C17.4568 17.0003 17.5948 17.117 17.7434 17.2231C17.1703 17.5627 16.576 17.8492 15.9499 18.0827C16.2789 18.73 16.6609 19.3456 17.0854 19.9187C18.8152 19.388 20.5875 18.5815 22.4033 17.2549C22.8596 12.7341 21.6806 8.80747 19.3034 5.33716ZM8.5201 14.8459C7.48007 14.8459 6.63107 13.9014 6.63107 12.7447C6.63107 11.5879 7.45884 10.6434 8.5201 10.6434C9.57071 10.6434 10.4303 11.5879 10.4091 12.7447C10.4091 13.9014 9.57071 14.8459 8.5201 14.8459ZM15.4936 14.8459C14.4535 14.8459 13.6034 13.9014 13.6034 12.7447C13.6034 11.5879 14.4323 10.6434 15.4936 10.6434C16.5442 10.6434 17.4038 11.5879 17.3825 12.7447C17.3825 13.9014 16.5548 14.8459 15.4936 14.8459Z">
                    </path>
                </svg>
            </li>
        </ul>
        <p class="text-center text-secondary">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="gray" width="20px" height="20px"><path d="M480,48H32A16,16,0,0,0,16,64V384a16,16,0,0,0,16,16H200v32H128v32H384V432H312V400H480a16,16,0,0,0,16-16V64A16,16,0,0,0,480,48ZM460,84V300H52V84ZM240.13,354.08a16,16,0,1,1,13.79,13.79A16,16,0,0,1,240.13,354.08Z"></path></svg>
            Desktop
        </p>
        <p class="text-center text-secondary">
            ©<?=$developer?>, 2024
        </p>
    </footer>
    <!-- Footer End -->
    <!-- akhir code disini -->

<!-- ///////////////////////////////////////////////////// -->
<script>
        $(document).ready(function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll > 100) {
                    $(".netflix-navbar").css("background", "#0C0C0C");
                } else {
                    $(".netflix-navbar").css("background", "transparent");
                }
            });
        });

        $(function () {
            $("[data-toggle=popover]").popover({
                html: true,
                content: function () {
                    var content = $(this).attr("data-popover-content");
                    return $(content).children(".popover-body").html();
                },
                title: function () {
                    var title = $(this).attr("data-popover-content");
                    return $(title).children(".popover-heading").html();
                }
            });

            // Close popover when clicking outside
            $(document).on('click', function (e) {
                if (!$(e.target).closest('[data-toggle="popover"]').length && !$(e.target).closest('.popover').length) {
                    $('[data-toggle="popover"]').popover('hide');
                }
            });

            // Close popover when clicking another popover trigger
            $(document).on('click', '[data-toggle="popover"]', function () {
                var $this = $(this);
                $('[data-toggle="popover"]').not($this).popover('hide');
            });
        });

    </script>

<script>
    window.onload = function() {
        <?php if(!empty($auto_refresh)): ?>
            <?php if($auto_refresh >= 1): ?>
                var secondz = <?= json_encode($auto_refresh * 1000) ?>; // Konversi ke milidetik
                var loadurl = <?= json_encode($siteurl . $shortlink . '?load=true') ?>;
                
                setTimeout(function() {
                    window.location.href = loadurl;
                }, secondz);
            <?php endif; ?>
        <?php endif; ?>
    };
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.cookie = 'refresh_count=1; expires=; path=/';
    });
</script>
<script type="text/javascript">
	history.replaceState({}, "", "<?php echo $currurl; ?>");
</script>
<?php if(preg_match('/^slot$/i', $adsense)){ ?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-<?php echo $ca_pub_id; ?>" crossorigin="anonymous"></script>
<?php } ?>
	
<?php if(preg_match('/^cse$/i', $adsense)){ ?>
            <script type="text/javascript">
                window.__gcse = {
                    callback: googleCSELoaded
                };

                function googleCSELoaded() {
                    // Pastikan google.search.cse tersedia
                    if (typeof google !== 'undefined' && google.search && google.search.cse) {
                        console.log("Google CSE loaded successfully.");

                        // Eksekusi pencarian pertama
                        var searchText = "<?php echo $csekey1; ?>";
                        var element = google.search.cse.element.getElement('searchOnlyCSE_one');
                        if (element) {
                            console.log("Executing search for searchOnlyCSE_one with text: " + searchText);
                            element.execute(searchText);
                        } else {
                            console.error("Element 'searchOnlyCSE_one' not found.");
                        }

                        // Eksekusi pencarian kedua
                        var searchText_2 = "<?php echo $csekey2; ?>";
                        var element_2 = google.search.cse.element.getElement('searchOnlyCSE_two');
                        if (element_2) {
                            console.log("Executing search for searchOnlyCSE_two with text: " + searchText_2);
                            element_2.execute(searchText_2);
                        } else {
                            console.error("Element 'searchOnlyCSE_two' not found.");
                        }
                    } else {
                        console.error("google.search.cse is not available.");
                    }
                }

                // Memuat skrip Google CSE
                (function() {
                    var cx = '<?php echo $cx_code; ?>'; // ID CSE Anda
                    var gcse = document.createElement('script');
                    gcse.type = 'text/javascript';
                    gcse.async = true;
                    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;

                    // Menambahkan skrip ke dalam halaman setelah elemen script pertama
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(gcse, s);

                    // Setelah skrip dimuat, eksekusi callback
                    gcse.onload = function() {
                        console.log("Google CSE script loaded.");
                        googleCSELoaded();
                    };

                    // Fallback jika onload tidak bekerja
                    gcse.onerror = function() {
                        console.error("Error loading Google CSE script.");
                    };
                })();
            </script>
		<?php } ?>
<?php if (!preg_match('/^afs$/i', $adsense)) { ?>
    <?php if ($deskripsi_artikel == 'ya') { ?>
        <hr>
        <?php
            // Mengamankan penggunaan strip_tags
            echo strip_tags(get_the_content(), '<p><a><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><strong><em><b><i>');
        ?>
    <?php } ?>
<?php } ?>
</body>
</html>