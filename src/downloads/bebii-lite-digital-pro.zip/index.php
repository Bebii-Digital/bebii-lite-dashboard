<?php
/*
Plugin Name: Bebii Lite Ads PRO
Plugin URI: https://bebiidigital.com/
Description: BebiiDigital Versi Lite
Version: 1.0.5
Author: Jamiat Abdillah
Author URI: https://www.facebook.com/jamiatabdillah
Slug: bebii-digital-lite-pro
*/

add_action('init', 'start_session', 1);
function start_session() {
    if (!session_id()) {
        session_start(); // Mulai sesi jika belum ada
    }
}

add_action('admin_menu', 'my_dashboard_menu');

function my_dashboard_menu() {
    // Menambahkan menu utama di sidebar admin
    add_menu_page(
        'Bebii Lite Ads',                   // Judul halaman
        'Bebii Lite Ads PRO',         // Nama menu di sidebar
        'manage_options',               // Kemampuan yang dibutuhkan untuk mengakses menu ini
        'Bebii_Lite_dashboard',         // Slug URL
        'Bebii_Lite_dashboard_page',    // Fungsi untuk menampilkan halaman
        'dashicons-dashboard',          // Icon menu (menggunakan icon dashboard)
        6                               // Posisi menu di sidebar
    );
}

if (is_admin()) {
add_filter('site_transient_update_plugins', function ($transient) {
    // Plugin slug dan versi saat ini
    $plugin_slug = 'bebii-lite-digital-pro';
    $plugin_data = get_plugin_data(__FILE__);
    $current_version = $plugin_data['Version'];

    // Cek cache transient
    $update_data = get_transient('bebii_plugin_update_data');
    if (false === $update_data) {
        // Kirim permintaan ke server hanya jika cache kosong
        $update_url = 'https://lite.bebiidigital.com/update-check';
        $response = wp_remote_get($update_url, ['timeout' => 3]);

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return $transient; // Tidak ada perubahan jika gagal
        }

        $update_data = json_decode(wp_remote_retrieve_body($response));
        if (isset($update_data->new_version)) {
            set_transient('bebii_plugin_update_data', $update_data, 12 * HOUR_IN_SECONDS); // Simpan data untuk 12 jam
        }
    }

    // Bandingkan versi dan tambahkan pembaruan jika diperlukan
    if (isset($update_data->new_version) && version_compare($current_version, $update_data->new_version, '<')) {
        $transient->response[$plugin_slug . '/index.php'] = (object) [
            'slug'        => $plugin_slug,
            'new_version' => $update_data->new_version,
            'package'     => $update_data->download_url,
            'tested'      => $update_data->tested,
            'requires'    => $update_data->requires,
        ];
    }

    return $transient;
});

add_filter('plugins_api', function ($result, $action, $args) {
    if ('plugin_information' !== $action || 'bebii-digital-lite-pro' !== $args->slug) {
        return $result;
    }

    $response = wp_remote_get('https://lite.bebiidigital.com/plugin-info');

    if (is_wp_error($response) || 200 !== 	   wp_remote_retrieve_response_code($response)) {
        return $result;
    }

	//echo "<script>alert('" . $response . "');</script>";
    $plugin_info = json_decode(wp_remote_retrieve_body($response));

    return (object) [
        'name'        => $plugin_info->name,
        'slug'        => $plugin_info->slug,
        'version'     => $plugin_info->version,
        'author'      => $plugin_info->author,
        'author_profile' => $plugin_info->author_profile,
        'homepage'    => $plugin_info->homepage,
        'download_link' => $plugin_info->download_url,
        'requires'    => $plugin_info->requires,
        'tested'      => $plugin_info->tested,
        'sections'    => [
            'description' => $plugin_info->description,
            'changelog'   => $plugin_info->changelog,
        ],
    ];
}, 10, 3);

// Fungsi untuk menampilkan halaman dashboard
function Bebii_Lite_dashboard_page() {
    // Menyertakan file tampilan dari folder views
    include(plugin_dir_path(__FILE__) . 'dash.php');
}

}

///////////////////////////////////////////////////////////////////////////////////////////////////////
function ambil_file($filex) {
    // Path file .txt (pastikan file ini ada dalam direktori plugin)
    $file_path = plugin_dir_path(__FILE__) . "assets/" . $filex;

    // Cek jika file ada
    if (file_exists($file_path)) {
        // Membaca isi file
        $file_content = file_get_contents($file_path);
        return $file_content;
    }

    return false;
}

// Fungsi untuk menampilkan string langsung
function ambil_data_text($filex) {
    $file_content = ambil_file($filex);
    if ($file_content) {
        return nl2br($file_content);  // Menampilkan konten file, dengan mempertahankan format baris baru
    } else {
        return "Not Found 404.";
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////

add_action('wp_head', 'head', 0);
function head(){
    if(isset($_GET['reset_transient'])){
        delete_transient('bebii_plugin_update_data');
    }
    if (file_exists(plugin_dir_path(__FILE__).'head.php')) {
        include(plugin_dir_path(__FILE__).'head.php');
    }
}

add_action( 'parse_request', 'sess' );
function sess(){
    if (file_exists(plugin_dir_path(__FILE__).'sess.php')) {
        include(plugin_dir_path(__FILE__).'sess.php');
    }
}

function random_select($data){
    $isjudul = preg_split('#(\r\n?|\n)+#', $data);
    $thejdlx = array();
    foreach($isjudul as $isjudulz){
        $thejdlx[] = trim($isjudulz);
    }
    shuffle($thejdlx);
    return $thejdlx[0];
}

function random_times(){
    return rand(25,59);
}
function random_seconds(){
    return rand(10,59);
}
function random_comma(){
    return rand(10,99);
}
function random_like(){
    return rand(30,300);
}
function random_unlike(){
    return rand(1,7);
}
function random_views(){
    return rand(400,999);
}

/////////////////////////////////////

add_action('wp_head', 'lempars', 0);

function lempars(){
	if(isset($_SESSION['themes_afs'])){

		include(plugin_dir_path(__FILE__).'Temp_'.$_SESSION['themes_afs'].'.php');
		include(plugin_dir_path(__FILE__).'afs.php');

		session_destroy();
	}
}

?>