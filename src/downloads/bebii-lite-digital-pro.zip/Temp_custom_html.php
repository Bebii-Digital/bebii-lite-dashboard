<?php

// Menangani URL
$siteurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/";
$currurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// Mengambil data dari file berdasarkan session
$fil = isset($_SESSION['slugID']) ? 'lp' . $_SESSION['slugID'] . '.txt' : 'defaultfile.txt';
$data_lp = ambil_data_text($fil);
$data_lp = preg_replace('#<br\s*/?>#i', '', $data_lp);
$data_lps = explode("\n", $data_lp);
$data_lps = array_map('trim', $data_lps);

// Validasi data dari file lp
$shortlink = isset($data_lps[0]) ? $data_lps[0] : '';
$deskripsi_artikel = isset($data_lps[3]) ? $data_lps[3] : '';
$auto_refresh = isset($data_lps[6]) ? $data_lps[6] : '';
$waktuRand = isset($data_lps[7]) ? $data_lps[7] : '';
$adsense = isset($data_lps[8]) ? $data_lps[8] : '';
$kode_html = isset($data_lps[9]) ? $data_lps[9] : '';

// Mengambil dan mengacak judul LP
$data_judul_lp = ambil_data_text('judul_lp.txt');
$data_judul_lp = preg_replace('#<br\s*/?>#i', '', $data_judul_lp);
$data_judul_lp = explode("\n", $data_judul_lp);
$judul_lp = array_map('trim', $data_judul_lp);
shuffle($judul_lp);
$developer = isset($judul_lp[0]) ? $judul_lp[0] : 'Developer';

// Mengambil dan mengacak video
$data_video = ambil_data_text('video.txt');
$data_video = preg_replace('#<br\s*/?>#i', '', $data_video);
$data_video = explode("\n", $data_video);
$video = array_map('trim', $data_video);
shuffle($video);

// Ambil data gambar
$data_gambar = ambil_data_text('gambar.txt');
$data_gambar = preg_replace('#<br\s*/?>#i', '', $data_gambar);
$data_gambar = explode("\n", $data_gambar);
$gambar = array_map('trim', $data_gambar);
shuffle($gambar);

// Mengambil dan mengacak judul
$data_judul = ambil_data_text('list_judul.txt');
$data_judul = preg_replace('#<br\s*/?>#i', '', $data_judul);
$data_judul = explode("\n", $data_judul);
$judul = array_map('trim', $data_judul);
shuffle($judul);

// Menangani data adsense
$data_ads = ambil_data_text('adsense.txt');
$data_ads = preg_replace('#<br\s*/?>#i', '', $data_ads);
$data_ads = explode("\n", $data_ads);
$data_ads = array_map('trim', $data_ads);

$ca_pub_id = isset($data_ads[0]) ? $data_ads[0] : '';
$cx_code = isset($data_ads[1]) ? $data_ads[1] : '';
$ads_1 = isset($data_ads[2]) ? preg_replace('/\\\\/', '', $data_ads[2]) : '';
$ads_2 = isset($data_ads[3]) ? preg_replace('/\\\\/', '', $data_ads[3]) : '';
$opacity = isset($data_ads[4]) ? $data_ads[4] : 100;
$cse_width_1 = isset($data_ads[5]) ? $data_ads[5] : 300;
$cse_width_2 = isset($data_ads[6]) ? $data_ads[6] : 300;
$cse_top_1 = isset($data_ads[7]) ? $data_ads[7] : 100;
$cse_top_2 = isset($data_ads[8]) ? $data_ads[8] : 100;
$slot_width_1 = isset($data_ads[9]) ? $data_ads[9] : 300;
$slot_width_2 = isset($data_ads[10]) ? $data_ads[10] : 300;
$slot_top_1 = isset($data_ads[11]) ? $data_ads[11] : 100;
$slot_bottom_2 = isset($data_ads[12]) ? $data_ads[12] : 100;

if (isset($_SESSION['testing']) && $_SESSION['testing'] == true) {
    $opacity = 70;
}

// Mengatur iklan berdasarkan adsense
if (preg_match('/^off$/i', $adsense)) {
    $iklan1 = '';
    $iklan2 = '';
} elseif (preg_match('/^cse$/i', $adsense)) {
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:' . $cse_top_1 . 'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:' . $cse_width_1 . 'px;overflow:hidden;margin:auto">
    <style>.gsc-above-wrapper-area,.gsc-resultsbox-visible{display:none;}</style><gcse:searchresults-only gname="searchOnlyCSE_one" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
    $iklan2 = '<div class="isAds2" style="display:block;position:fixed;top:' . $cse_top_2 . 'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:' . $cse_width_2 . 'px;overflow:hidden;margin:auto">
    <gcse:searchresults-only gname="searchOnlyCSE_two" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
} elseif (preg_match('/^slot$/i', $adsense)) {
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:' . $slot_top_1 . 'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:' . $slot_width_1 . 'px;height:100%;overflow:hidden;margin:auto">' . $ads_1 . '</div></div>';
    $iklan2 = '<div class="isAds" style="display:block;position:fixed;top:' . $slot_bottom_2 . 'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:' . $slot_width_2 . 'px;height:100%;overflow:hidden;margin:auto">' . $ads_2 . '</div></div>';
} elseif (preg_match('/^infeed$/i', $adsense)) {
    $iklan1 = '<div class="isAds" style="height:100%;display:block;position:fixed;top:' . $infeed_top_1 . 'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:' . $infeed_width_1 . 'px;height:100%;overflow:hidden;margin:auto">' . $infeed_1 . '</div></div>';
    $iklan2 = '<div class="isAds2" style="height:100%;display:block;position:fixed;top:' . $infeed_top_2 . 'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:' . $infeed_width_2 . 'px;height:100%;overflow:hidden;margin:auto">' . $infeed_2 . '</div></div>';
}

// Memproses data hpk
$data_hpk = ambil_data_text('hpk.txt');
$data_hpk = str_replace(['<br>', '<br/>', '<br />'], '', $data_hpk);
$hpk_keywordx = preg_split('#(\r\n?|\n)+#', $data_hpk);

shuffle($hpk_keywordx);
$csekey1 = isset($hpk_keywordx[0]) ? $hpk_keywordx[0] : '';
$csekey2 = isset($hpk_keywordx[1]) ? $hpk_keywordx[1] : '';

// Menghapus session yang tidak diperlukan
unset($_SESSION['slugID2']);
unset($_SESSION['slugLINK2']);
session_destroy();
?>

<!DOCTYPE html>
<html lang="en-US">
<head itemscope="itemscope" itemtype="http://schema.org/WebSite">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#9a1518" />
<title><?= get_the_title(); ?></title>
<link href="//www.youtube.com" rel="preconnect dns-prefetch">
<link href="//pagead2.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//googleads.g.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//ad.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//i.ytimg.com" rel="preconnect dns-prefetch">
<link href="//www.gstatic.com" rel="preconnect dns-prefetch">
<link href="//www.google.com" rel="preconnect dns-prefetch">
<link href="//cse.google.com" rel="preconnect dns-prefetch">
<link href="//tpc.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//www.google-analytics.com" rel="preconnect dns-prefetch">
<link href="//yt3.ggpht.com" rel="preconnect dns-prefetch">
<link href="//cdn.jsdelivr.net" rel="preconnect dns-prefetch">
<link href="//fonts.gstatic.com" rel="preconnect dns-prefetch">
<link href="//adservice.google.com" rel="preconnect dns-prefetch">
<link href="//ajax.cloudflare.com" rel="preconnect dns-prefetch">
<link href="//www.googletagmanager.com" rel="preconnect dns-prefetch">
<link href="//partner.googleadservices.com" rel="preconnect dns-prefetch">
<link href="//www.googletagservices.com" rel="preconnect dns-prefetch">
<link href="//static.doubleclick.net" rel="preconnect dns-prefetch">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
    <style>
        :root{
            --bebii-primary: #f8f9fa;
            --bebii-background: #001000;
            --bebii-component: #29393e;
            --bebii-secondary: #FDA508;
            --bebii-first-text: #25ce3f;
            --bebii-second-text: #69a5e1;
            --bebii-third-text: #ff0000;
            --bebii-fourth-text: #ff00ff;
        }
    </style>
<!-- batas -->
<style>
.navbar-icon-top .navbar-nav .nav-link > .fa { position: relative; width: 36px; font-size: 24px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { font-size: 0.75rem; position: absolute; right: 0; font-family: sans-serif; } .navbar-icon-top .navbar-nav .nav-link > .fa { top: 3px; line-height: 12px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { top: -10px; } @media (min-width: 576px) { .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 768px) { .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 992px) { .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 1200px) { .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa > .badge { top: -7px; } }
body { background-color: #383838; }.cont_ads1{display:block;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);height:auto !important;opacity:<?php echo $opacity; ?>%;z-index:2;width:100%;} .img-drop{width:100%;background-position:center;background-size:cover;object-fit:cover;} .info-bar { padding: 0.3rem; margin: -0.1rem 0 0 0; background-color: #ffffff; box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23); } .info-word { font-size: 2.85rem; margin-top: 0.2rem; margin-bottom: 0.2rem; transition: 0.5s; } .info-word:hover { color: #306a86; } .islike{font-size: 1.85rem;} .play-btns{font-size:3rem;} .views { font-size: 0.9rem; padding-left: 0.5rem; display: inline; margin: 0; } .likes { font-size: 0.9rem; color: #a0903f; margin: 0; display: inline; } .likes-col { padding-left: 2rem; text-align: left; } .title { padding-left: 1rem; font-size: 2rem; } .info-row { padding: 0 0.5rem; text-align: center; } .fa, .fas { color: #55556c; } .fa-thumbs-up { color: #a0903f; } .fa-thumbs-up:hover { color: #877b3b; } a:hover { text-decoration: none; } @media screen and (min-width: 992px) {.play-btns{font-size:5rem;} .img-drop{height:490px;}.h2-rel{font-size: 1.5rem;} .col-lg-2 { padding: 10px 10px 5px 10px; padding-top:0px; } } @media screen and (max-device-width: 992px) { .h2-rel{font-size: 1.3rem;} .img-drop{height:390px;} .info-row { text-align: left; } } @media screen and (max-device-width: 576px) {.img-drop{height:190px;} .info-word { font-size: 1rem; } .likes, .views { font-size: 0.75rem; } .islike{font-size: 0.7rem;} .title { padding-left: 0rem; font-size: 1.15rem; } .likes-col { padding-left: 1rem; text-align: left; } .info-row { padding: 0 0.2rem; } }
.isAds { position: absolute; top: 0; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; } #isAdsC, #isAdsC2 { max-width: 500px; } @media screen and (max-width: 767px) { .isAds, .isAds2 { height: auto; position: relative; } #isAdsC, #isAdsC2 { position: static; top: auto; left: auto; right: auto; opacity: 1; max-width: 500px; } } .isAds2 { position: absolute; bottom: 0px; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; }
</style>


<?php if(preg_match('/^slot$/i', $adsense)){ ?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-<?php echo $ca_pub_id; ?>" crossorigin="anonymous"></script>
<?php } ?>
<!-- batas -->
</head>
<body id="badan">
<script>
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', () => {
        window.location.href = window.location.href;
    });
</script>

<?php echo $iklan1; ?>
<?php echo $iklan2; ?>

<section>
    <?= $kode_html ?>        
</section>

<script>
    window.onload = function() {
        <?php if(!empty($auto_refresh)): ?>
            <?php if($auto_refresh >= 1): ?>
                var secondz = <?= json_encode($auto_refresh * 1000) ?>; // Konversi ke milidetik
                var loadurl = <?= json_encode($siteurl . $shortlink . '?load=true') ?>;
                
                setTimeout(function() {
                    window.location.href = loadurl;
                }, secondz);
            <?php endif; ?>
        <?php endif; ?>
    };
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.cookie = 'refresh_count=1; expires=; path=/';
    });
</script>
<script type="text/javascript">
	history.replaceState({}, "", "<?php echo $currurl; ?>");
</script>
	
        <?php if(preg_match('/^cse$/i', $adsense)){ ?>
            <script type="text/javascript">
                window.__gcse = {
                    callback: googleCSELoaded
                };

                function googleCSELoaded() {
                    // Pastikan google.search.cse tersedia
                    if (typeof google !== 'undefined' && google.search && google.search.cse) {
                        console.log("Google CSE loaded successfully.");

                        // Eksekusi pencarian pertama
                        var searchText = "<?php echo $csekey1; ?>";
                        var element = google.search.cse.element.getElement('searchOnlyCSE_one');
                        if (element) {
                            console.log("Executing search for searchOnlyCSE_one with text: " + searchText);
                            element.execute(searchText);
                        } else {
                            console.error("Element 'searchOnlyCSE_one' not found.");
                        }

                        // Eksekusi pencarian kedua
                        var searchText_2 = "<?php echo $csekey2; ?>";
                        var element_2 = google.search.cse.element.getElement('searchOnlyCSE_two');
                        if (element_2) {
                            console.log("Executing search for searchOnlyCSE_two with text: " + searchText_2);
                            element_2.execute(searchText_2);
                        } else {
                            console.error("Element 'searchOnlyCSE_two' not found.");
                        }
                    } else {
                        console.error("google.search.cse is not available.");
                    }
                }

                // Memuat skrip Google CSE
                (function() {
                    var cx = '<?php echo $cx_code; ?>'; // ID CSE Anda
                    var gcse = document.createElement('script');
                    gcse.type = 'text/javascript';
                    gcse.async = true;
                    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;

                    // Menambahkan skrip ke dalam halaman setelah elemen script pertama
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(gcse, s);

                    // Setelah skrip dimuat, eksekusi callback
                    gcse.onload = function() {
                        console.log("Google CSE script loaded.");
                        googleCSELoaded();
                    };

                    // Fallback jika onload tidak bekerja
                    gcse.onerror = function() {
                        console.error("Error loading Google CSE script.");
                    };
                })();
            </script>
		<?php } ?>
<?php if (!preg_match('/^afs$/i', $adsense)) { ?>
    <?php if ($deskripsi_artikel == 'ya') { ?>
        <hr>
        <?php
        // Mengamankan penggunaan strip_tags
        echo strip_tags(get_the_content(), '<p><a><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><strong><em><b><i>');
        ?>
    <?php } ?>
<?php } ?>
</body>
</html>