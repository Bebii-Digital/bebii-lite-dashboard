<?php

// Menangani URL
$siteurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/";
$currurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// Mengambil data dari file LP berdasarkan session
$fil = isset($_SESSION['slugID']) ? 'lp' . $_SESSION['slugID'] . '.txt' : 'defaultfile.txt';
$data_lp = ambil_data_text($fil);
$data_lp = preg_replace('#<br\s*/?>#i', '', $data_lp);
$data_lps = explode("\n", $data_lp);
$data_lps = array_map('trim', $data_lps);

// Validasi data LP
$shortlink = isset($data_lps[0]) ? $data_lps[0] : '';
$deskripsi_artikel = isset($data_lps[3]) ? $data_lps[3] : '';
$auto_refresh = isset($data_lps[6]) ? $data_lps[6] : '';
$waktuRand = isset($data_lps[7]) ? $data_lps[7] : '';
$adsense = isset($data_lps[8]) ? $data_lps[8] : '';

// Mengambil dan mengacak judul LP
$data_judul_lp = ambil_data_text('judul_lp.txt');
$data_judul_lp = preg_replace('#<br\s*/?>#i', '', $data_judul_lp);
$data_judul_lp = explode("\n", $data_judul_lp);
$judul_lp = array_map('trim', $data_judul_lp);
shuffle($judul_lp);
$developer = isset($judul_lp[0]) ? $judul_lp[0] : 'Developer';

// Mengambil dan mengacak video
$data_video = ambil_data_text('video.txt');
$data_video = preg_replace('#<br\s*/?>#i', '', $data_video);
$data_video = explode("\n", $data_video);
$video = array_map('trim', $data_video);
shuffle($video);

// Ambil data gambar
$data_gambar = ambil_data_text('gambar.txt');
$data_gambar = preg_replace('#<br\s*/?>#i', '', $data_gambar);
$data_gambar = explode("\n", $data_gambar);
$gambar = array_map('trim', $data_gambar);
shuffle($gambar);

// Mengambil dan mengacak judul
$data_judul = ambil_data_text('list_judul.txt');
$data_judul = preg_replace('#<br\s*/?>#i', '', $data_judul);
$data_judul = explode("\n", $data_judul);
$judul = array_map('trim', $data_judul);
shuffle($judul);

// Mengambil data Adsense
$data_ads = ambil_data_text('adsense.txt');
$data_ads = preg_replace('#<br\s*/?>#i', '', $data_ads);
$data_ads = explode("\n", $data_ads);
$data_ads = array_map('trim', $data_ads);

// Validasi data Adsense
$ca_pub_id = isset($data_ads[0]) ? $data_ads[0] : '';
$cx_code = isset($data_ads[1]) ? $data_ads[1] : '';
$ads_1 = isset($data_ads[2]) ? preg_replace('/\\\\/', '', $data_ads[2]) : '';
$ads_2 = isset($data_ads[3]) ? preg_replace('/\\\\/', '', $data_ads[3]) : '';
$opacity = isset($data_ads[4]) ? $data_ads[4] : 100;
$cse_width_1 = isset($data_ads[5]) ? $data_ads[5] : 300;
$cse_width_2 = isset($data_ads[6]) ? $data_ads[6] : 300;
$cse_top_1 = isset($data_ads[7]) ? $data_ads[7] : 100;
$cse_top_2 = isset($data_ads[8]) ? $data_ads[8] : 100;
$slot_width_1 = isset($data_ads[9]) ? $data_ads[9] : 300;
$slot_width_2 = isset($data_ads[10]) ? $data_ads[10] : 300;
$slot_top_1 = isset($data_ads[11]) ? $data_ads[11] : 100;
$slot_bottom_2 = isset($data_ads[12]) ? $data_ads[12] : 100;

if(isset($_SESSION['testing']) && $_SESSION['testing'] == true){
    $opacity = 70;
}

if(preg_match('/^off$/i', $adsense)){
    $iklan1 = '';
    $iklan2 = '';
}elseif(preg_match('/^cse$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:'.$cse_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$cse_width_1.'px;overflow:hidden;margin:auto">
    <style>.gsc-above-wrapper-area,.gsc-resultsbox-visible{display:none;}</style><gcse:searchresults-only gname="searchOnlyCSE_one" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
    $iklan2 = '<div class="isAds2" style="display:block;position:fixed;top:'.$cse_top_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$cse_width_2.'px;overflow:hidden;margin:auto">
    <gcse:searchresults-only gname="searchOnlyCSE_two" enablehistory="false"></gcse:searchresults-only>
    </div></div>';
}elseif(preg_match('/^slot$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="display:block;position:fixed;top:'.$slot_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$slot_width_1.'px;height:100%;overflow:hidden;margin:auto">'.$ads_1.'</div></div>';
    $iklan2 = '<div class="isAds2" style="display:block;position:fixed;top:'.$slot_bottom_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$slot_width_2.'px;height:100%;overflow:hidden;margin:auto">'.$ads_2.'</div></div>';
}elseif(preg_match('/^infeed$/i', $adsense)){
    $iklan1 = '<div class="isAds" style="height:100%;display:block;position:fixed;top:'.$infeed_top_1.'px;"><div id="isAdsC" style="text-align:center;display:block;max-width:'.$infeed_width_1.'px;height:100%;overflow:hidden;margin:auto">'.$infeed_1.'</div></div>';
    $iklan2 = '<div class="isAds2" style="height:100%;display:block;position:fixed;top:'.$infeed_top_2.'px;"><div id="isAdsC2" style="text-align:center;display:block;max-width:'.$infeed_width_2.'px;height:100%;overflow:hidden;margin:auto">'.$infeed_2.'</div></div>';
}

// Mengambil data HPK
$data_hpk = ambil_data_text('hpk.txt');
$data_hpk = str_replace(['<br>', '<br/>', '<br />'], '', $data_hpk);
$hpk_keywordx = preg_split('#(\r\n?|\n)+#', $data_hpk);

// Validasi data HPK
shuffle($hpk_keywordx);
$csekey1 = isset($hpk_keywordx[0]) ? $hpk_keywordx[0] : '';
$csekey2 = isset($hpk_keywordx[1]) ? $hpk_keywordx[1] : '';

$timeplay = random_times();

$loadurl = $siteurl . $shortlink.'?load='. (isset($idmd5z) ? $idmd5z : '');

unset($_SESSION['slugID2']);
unset($_SESSION['slugLINK2']);
session_destroy();
?>
<!DOCTYPE html>
<html lang="en-US">
<head itemscope="itemscope" itemtype="http://schema.org/WebSite">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#9a1518" />
<title><?= get_the_title(); ?></title>
<link href="//www.youtube.com" rel="preconnect dns-prefetch">
<link href="//pagead2.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//googleads.g.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//ad.doubleclick.net" rel="preconnect dns-prefetch">
<link href="//i.ytimg.com" rel="preconnect dns-prefetch">
<link href="//www.gstatic.com" rel="preconnect dns-prefetch">
<link href="//www.google.com" rel="preconnect dns-prefetch">
<link href="//cse.google.com" rel="preconnect dns-prefetch">
<link href="//tpc.googlesyndication.com" rel="preconnect dns-prefetch">
<link href="//www.google-analytics.com" rel="preconnect dns-prefetch">
<link href="//yt3.ggpht.com" rel="preconnect dns-prefetch">
<link href="//cdn.jsdelivr.net" rel="preconnect dns-prefetch">
<link href="//fonts.gstatic.com" rel="preconnect dns-prefetch">
<link href="//adservice.google.com" rel="preconnect dns-prefetch">
<link href="//ajax.cloudflare.com" rel="preconnect dns-prefetch">
<link href="//www.googletagmanager.com" rel="preconnect dns-prefetch">
<link href="//partner.googleadservices.com" rel="preconnect dns-prefetch">
<link href="//www.googletagservices.com" rel="preconnect dns-prefetch">
<link href="//static.doubleclick.net" rel="preconnect dns-prefetch">
	
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"/>

<style>
.navbar-icon-top .navbar-nav .nav-link > .fa { position: relative; width: 36px; font-size: 24px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { font-size: 0.75rem; position: absolute; right: 0; font-family: sans-serif; } .navbar-icon-top .navbar-nav .nav-link > .fa { top: 3px; line-height: 12px; } .navbar-icon-top .navbar-nav .nav-link > .fa > .badge { top: -10px; } @media (min-width: 576px) { .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-sm .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 768px) { .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-md .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 992px) { .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-lg .navbar-nav .nav-link > .fa > .badge { top: -7px; } } @media (min-width: 1200px) { .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link { text-align: center; display: table-cell; height: 70px; vertical-align: middle; padding-top: 0; padding-bottom: 0; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa { display: block; width: 48px; margin: 2px auto 4px auto; top: 0; line-height: 24px; } .navbar-icon-top.navbar-expand-xl .navbar-nav .nav-link > .fa > .badge { top: -7px; } }
body { background-color: #383838; }.cont_ads1{display:block;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);height:auto !important;opacity:<?php echo $opacity; ?>%;z-index:2;width:100%;} .img-drop{width:100%;background-position:center;background-size:cover;object-fit:cover;} .info-bar { padding: 0.3rem; margin: -0.1rem 0 0 0; background-color: #ffffff; box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23); } .info-word { font-size: 2.85rem; margin-top: 0.2rem; margin-bottom: 0.2rem; transition: 0.5s; } .info-word:hover { color: #306a86; } .islike{font-size: 1.85rem;} .play-btns{font-size:3rem;} .views { font-size: 0.9rem; padding-left: 0.5rem; display: inline; margin: 0; } .likes { font-size: 0.9rem; color: #a0903f; margin: 0; display: inline; } .likes-col { padding-left: 2rem; text-align: left; } .title { padding-left: 1rem; font-size: 2rem; } .info-row { padding: 0 0.5rem; text-align: center; } .fa, .fas { color: #55556c; } .fa-thumbs-up { color: #a0903f; } .fa-thumbs-up:hover { color: #877b3b; } a:hover { text-decoration: none; } @media screen and (min-width: 992px) {.play-btns{font-size:5rem;} .img-drop{height:490px;}.h2-rel{font-size: 1.5rem;} .col-lg-2 { padding: 10px 10px 5px 10px; padding-top:0px; } } @media screen and (max-device-width: 992px) { .h2-rel{font-size: 1.3rem;} .img-drop{height:390px;} .info-row { text-align: left; } } @media screen and (max-device-width: 576px) {.img-drop{height:190px;} .info-word { font-size: 1rem; } .likes, .views { font-size: 0.75rem; } .islike{font-size: 0.7rem;} .title { padding-left: 0rem; font-size: 1.15rem; } .likes-col { padding-left: 1rem; text-align: left; } .info-row { padding: 0 0.2rem; } }
.isAds { position: absolute; top: 0; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; } #isAdsC, #isAdsC2 { max-width: 500px; } @media screen and (max-width: 767px) { .isAds, .isAds2 { height: auto; position: relative; } #isAdsC, #isAdsC2 { position: static; top: auto; left: auto; right: auto; opacity: 1; max-width: 500px; } } .isAds2 { position: absolute; bottom: 0px; left: 0; width: 100%; height: 9%; opacity: <?php echo $opacity; ?>%; z-index: 2; }
</style>

<style>
</style>
    
    <style>
        :root {
            --base-color-root: #fff;
            --secondary-color-root: #f22424;
            --text-color-root: #212529;
            --gray-color-root: #a6a6a6;
        }

        body,
        html {
            background-color: var(--base-color-root);
            overflow-x: hidden;
        }
    </style>

<!-- batas -->
</head>
<body class="position-relative min-vh-100 d-flex flex-column" style="overflow-y: auto;">
<script>
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', () => {
        window.location.href = window.location.href;
    });
</script>

<div id="bungkus-iklan">
    <?php echo $iklan1; ?>
	<?php echo $iklan2; ?>
</div>

<!-- awal code -->
    <nav class="d-flex align-items-center justify-content-between top-0 p-2 w-100 shadow mb-1" style="background-color: var(--base-color-root);">
        <div>
            <svg width="25px" height="25px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" fill="var(--text-color-root)">
                <path d="M904 160H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0 624H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0-312H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8z">
                </path>
            </svg>
        </div>
        <h1 class="m-0" style="color: var(--secondary-color-root);">
            <?php $satuHurufPertama = substr($developer, 0, 1); ?>
            <?php $hurufSelanjutnya = substr($developer, 1); ?>
            <span class="rounded-1 py-0" style="padding: 0.2rem; background-color: var(--secondary-color-root);color: var(--base-color-root);"><?= $satuHurufPertama ?></span><?= $hurufSelanjutnya ?>
        </h1>
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="var(--text-color-root)" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0">
                </path>
            </svg>
        </div>
    </nav>

    <section class="d-flex flex-column w-100 flex-grow-1 pb-5" style="background-color: var(--base-color-root);">    
        <div class="d-grid px-2" style="padding-bottom: 30px; padding-top: 20px;">
			<div class="card shadow col-12 mb-3" style="background-color: var(--base-color-root);">
			<div class="position-relative overflow-hidden">
				<span id="vid-utama" class="play-pause-btn w-100 h-100 position-absolute d-flex align-items-center justify-content-center" style="top: 0%; left: 0%;z-index: 1;">
				</span>
				<video width="100%" id="myVideo" class="myVideo" preload="none" playsinline controls muted autoplay>
					<source src="<?= $video[0] ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
			</div>

			<script>
				// Define an array of colors
				const colorData = ["#ef3aa5", "#ff8906", "#b8c1ec", "#6246ea", "#ffd803"]; // Example colors
				const getRandomColor = () => colorData[Math.floor(Math.random() * colorData.length)];
				const randomColor = getRandomColor();
				document.documentElement.style.setProperty('--bebii-play-btn-color', randomColor);
				const playIcon = `<svg viewBox="0 0 48 48" width="45%" height="45%" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_1493_662)">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M44 24C44 35.0457 35.0457 44 24 44C12.9543 44 4 35.0457 4 24C4 12.9543 12.9543 4 24 4C35.0457 4 44 12.9543 44 24ZM26 20.5359L20 17.0718V24V30.9282L26 27.4641L32 24L26 20.5359Z" fill="var(--bebii-play-btn-color)"/>
                                    <path d="M20 17.0718L20.5 16.2058C20.1906 16.0271 19.8094 16.0271 19.5 16.2058C19.1906 16.3844 19 16.7145 19 17.0718H20ZM20 30.9282H19C19 31.2854 19.1906 31.6156 19.5 31.7942C19.8094 31.9728 20.1906 31.9728 20.5 31.7942L20 30.9282ZM32 24L32.5 24.866C32.8094 24.6874 33 24.3572 33 24C33 23.6427 32.8094 23.3126 32.5 23.134L32 24ZM24 45C35.598 45 45 35.598 45 24H43C43 34.4934 34.4934 43 24 43V45ZM3 24C3 35.598 12.402 45 24 45V43C13.5066 43 5 34.4934 5 24H3ZM24 3C12.402 3 3 12.402 3 24H5C5 13.5066 13.5066 5 24 5V3ZM45 24C45 12.402 35.598 3 24 3V5C34.4934 5 43 13.5066 43 24H45ZM19.5 17.9378L25.5 21.4019L26.5 19.6699L20.5 16.2058L19.5 17.9378ZM21 24V17.0718H19V24H21ZM21 30.9282V24H19V30.9282H21ZM25.5 26.5981L19.5 30.0622L20.5 31.7942L26.5 28.3301L25.5 26.5981ZM31.5 23.134L25.5 26.5981L26.5 28.3301L32.5 24.866L31.5 23.134ZM25.5 21.4019L31.5 24.866L32.5 23.134L26.5 19.6699L25.5 21.4019Z" fill="var(--bebii-play-btn-color)"/>
                                </g>
                            </svg>
                            `;
                document.addEventListener('DOMContentLoaded', (event) => {
					const video = document.getElementById('myVideo');
					const vidUtama = document.getElementById("vid-utama");
					let hasPaused = false;
					const playPauseBtn = document.querySelectorAll('.play-pause-btn');

					playPauseBtn.forEach(btn => {
						btn.innerHTML = playIcon;
					});

					video.addEventListener('play', () => {
						if (!hasPaused) {
							const randomTime = <?= $waktuRand ?> * 1000;
						vidUtama.innerHTML = "";
						setTimeout(() => {
							video.pause();
							vidUtama.innerHTML = playIcon;
							hasPaused = true;
						}, randomTime);
						}
					});

					vidUtama.addEventListener('click', () => {
						if (video.paused) {
							video.play();
							vidUtama.innerHTML = "";
						} else{
							video.pause();
							vidUtama.innerHTML = playIcon;
						}
					});
				});
			</script>
				
				<div class="card-body">
                    <h5 class="card-title"><?= $judul[0] ?></h5>
                    <span class="d-flex align-items-center gap-1" style="color: var(--gray-color-root);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z">
                            </path>
                            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0">
                            </path>
                        </svg>
                        <span>
                            <script>
                                document.write((Math.floor(Math.random() * 1_000) +301).toLocaleString());
                            </script>K
                        </span>
                        <svg width="16" height="16" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect fill="white" fill-opacity="0.01">
                            </rect>
                            <path d="M24 33C28.9706 33 33 28.9706 33 24C33 19.0294 28.9706 15 24 15C19.0294 15 15 19.0294 15 24C15 28.9706 19.0294 33 24 33Z" fill="currentColor" stroke="currentColor" stroke-width="2">
                            </path>
                        </svg>
                        <span>
                            <script>
                                document.write((Math.floor(Math.random() * 10) +1).toLocaleString());
                            </script> days ago
                        </span>
                    </span>
                </div>
			</div>
            <!-- Loop Content -->
            <?php $jumlah_loop = 5; ?>
            <?php 
                for ($i=0; $i < $jumlah_loop; $i++) {
                    shuffle($judul);
                    shuffle($gambar);
            ?>
            <div class="card shadow col-12 mb-3" style="background-color: var(--base-color-root);">
				<div class="position-relative overflow-hidden">
					<span class="play-pause-btn w-100 h-100 position-absolute d-flex align-items-center justify-content-center" style="top: 0%; left: 0%;z-index: 1;">
					</span>
					<img class="w-100" src="<?= $gambar[1] ?>" alt="" style="object-fit: cover;height: 180px;">
				</div>
                <div class="card-body">
                    <h5 class="card-title"><?= $judul[0] ?></h5>
                    <span class="d-flex align-items-center gap-1" style="color: var(--gray-color-root);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z">
                            </path>
                            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0">
                            </path>
                        </svg>
                        <span>
                            <script>
                                document.write((Math.floor(Math.random() * 1_000) +301).toLocaleString());
                            </script>K
                        </span>
                        <svg width="16" height="16" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect fill="white" fill-opacity="0.01">
                            </rect>
                            <path d="M24 33C28.9706 33 33 28.9706 33 24C33 19.0294 28.9706 15 24 15C19.0294 15 15 19.0294 15 24C15 28.9706 19.0294 33 24 33Z" fill="currentColor" stroke="currentColor" stroke-width="2">
                            </path>
                        </svg>
                        <span>
                            <script>
                                document.write((Math.floor(Math.random() * 10) +1).toLocaleString());
                            </script> days ago
                        </span>
                    </span>
                </div>
            </div>
            <?php } ?>
            <!-- End Loop Content -->

            <!-- Load More -->
            <div class="d-flex justify-content-center">
                <button class="btn fw-bold w-100" style="background-color: var(--base-color-root);color: #FFFFFF;border-color: var(--gray-color-root);">
                    More Recommendation Videos
                </button>
            </div>
			
        </div>
    </section>

    <footer class="fixed-bottom" style="background-color: var(--base-color-root);color: var(--text-color-root); z-index: 1;">
        <div class="d-flex justify-content-around p-2 gap-1" style="overflow-x: hidden;border-top: 4px solid var(--secondary-color-root);">
            <div class="d-flex flex-column justify-content-center align-items-center">
                <svg class="flex-grow-1 flex-shrink-1" width="1.4rem" height="1.4rem" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 21" fill="currentColor"><g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(1 1)"><path d="m.5 9.5 9-9 9 9"></path><path d="m2.5 7.5v7c0 1.1045695.8954305 2 2 2h10c1.1045695 0 2-.8954305 2-2v-7"></path></g></svg>
                <span>Home</span>
            </div>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <svg class="flex-grow-1 flex-shrink-1" width="2rem" height="2rem" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 21" fill="currentColor"><path d="m2.5.5h6c1.1045695 0 2 .8954305 2 2v4c0 1.1045695-.8954305 2-2 2h-6c-1.1045695 0-2-.8954305-2-2v-4c0-1.1045695.8954305-2 2-2zm8 3 2.4-1.8c.4418278-.33137085 1.0686292-.2418278 1.4.2.1298221.17309617.2.38362979.2.6v4c0 .55228475-.4477153 1-1 1-.2163702 0-.4269038-.07017787-.6-.2l-2.4-1.8z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(3 6)"></path></svg>
                <span>Videos</span>
            </div>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <svg class="flex-grow-1 flex-shrink-1" width="1.4rem" height="1.4rem" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M2.5 3.5a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1zm2-2a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1zM0 13a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 16 13V6a1.5 1.5 0 0 0-1.5-1.5h-13A1.5 1.5 0 0 0 0 6zm1.5.5A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5z"></path>
                  </svg>
                <span>Collections</span>
            </div>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <svg class="flex-grow-1 flex-shrink-1" width="1.4rem" height="1.4rem" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" color="currentColor"><path d="M6.57757 15.4816C5.1628 16.324 1.45336 18.0441 3.71266 20.1966C4.81631 21.248 6.04549 22 7.59087 22H16.4091C17.9545 22 19.1837 21.248 20.2873 20.1966C22.5466 18.0441 18.8372 16.324 17.4224 15.4816C14.1048 13.5061 9.89519 13.5061 6.57757 15.4816Z" stroke="currentColor"></path><path d="M16.5 6.5C16.5 8.98528 14.4853 11 12 11C9.51472 11 7.5 8.98528 7.5 6.5C7.5 4.01472 9.51472 2 12 2C14.4853 2 16.5 4.01472 16.5 6.5Z" stroke="currentColor"></path></svg>
                <span>Account</span>
            </div>
        </div>
    </footer>
    <!-- akhir code disini -->

<!-- ///////////////////////////////////////////////////// -->

<script>
    window.onload = function() {
        <?php if(!empty($auto_refresh)): ?>
            <?php if($auto_refresh >= 1): ?>
                var secondz = <?= json_encode($auto_refresh * 1000) ?>; // Konversi ke milidetik
                var loadurl = <?= json_encode($siteurl . $shortlink . '?load=true') ?>;
                
                setTimeout(function() {
                    window.location.href = loadurl;
                }, secondz);
            <?php endif; ?>
        <?php endif; ?>
    };
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.cookie = 'refresh_count=1; expires=; path=/';
    });
</script>
<script type="text/javascript">
	history.replaceState({}, "", "<?php echo $currurl; ?>");
</script>
<?php if(preg_match('/^slot$/i', $adsense)){ ?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-<?php echo $ca_pub_id; ?>" crossorigin="anonymous"></script>
<?php } ?>
	
<?php if(preg_match('/^cse$/i', $adsense)){ ?>
            <script type="text/javascript">
                window.__gcse = {
                    callback: googleCSELoaded
                };

                function googleCSELoaded() {
                    // Pastikan google.search.cse tersedia
                    if (typeof google !== 'undefined' && google.search && google.search.cse) {
                        console.log("Google CSE loaded successfully.");

                        // Eksekusi pencarian pertama
                        var searchText = "<?php echo $csekey1; ?>";
                        var element = google.search.cse.element.getElement('searchOnlyCSE_one');
                        if (element) {
                            console.log("Executing search for searchOnlyCSE_one with text: " + searchText);
                            element.execute(searchText);
                        } else {
                            console.error("Element 'searchOnlyCSE_one' not found.");
                        }

                        // Eksekusi pencarian kedua
                        var searchText_2 = "<?php echo $csekey2; ?>";
                        var element_2 = google.search.cse.element.getElement('searchOnlyCSE_two');
                        if (element_2) {
                            console.log("Executing search for searchOnlyCSE_two with text: " + searchText_2);
                            element_2.execute(searchText_2);
                        } else {
                            console.error("Element 'searchOnlyCSE_two' not found.");
                        }
                    } else {
                        console.error("google.search.cse is not available.");
                    }
                }

                // Memuat skrip Google CSE
                (function() {
                    var cx = '<?php echo $cx_code; ?>'; // ID CSE Anda
                    var gcse = document.createElement('script');
                    gcse.type = 'text/javascript';
                    gcse.async = true;
                    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;

                    // Menambahkan skrip ke dalam halaman setelah elemen script pertama
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(gcse, s);

                    // Setelah skrip dimuat, eksekusi callback
                    gcse.onload = function() {
                        console.log("Google CSE script loaded.");
                        googleCSELoaded();
                    };

                    // Fallback jika onload tidak bekerja
                    gcse.onerror = function() {
                        console.error("Error loading Google CSE script.");
                    };
                })();
            </script>
		<?php } ?>
    
<?php if (!preg_match('/^afs$/i', $adsense)) { ?>
    <?php if ($deskripsi_artikel == 'ya') { ?>
        <hr>
        <?php
            // Mengamankan penggunaan strip_tags
            echo strip_tags(get_the_content(), '<p><a><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><strong><em><b><i>');
        ?>
    <?php } ?>
<?php } ?>
</body>
</html>