<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }

  .hidden {
    display: none;
  }

  .responsive-konten {
    position: absolute;
    width: 85%;
    height: 85%;
    top: 55%;
    left: 50%;
    transform: translate(-50%, -50%);
    object-fit: cover;
  }
</style>

<div id="pageContent" class="hidden">
  <!-- Original page content goes here -->
</div>

<?php
if(isset($_SESSION['testing']) && $_SESSION['testing'] == true){
    $opacity = 40;
	$opacity2 = 40;
?>
<script>
		  (function() {
			var isAdsArea = false;
			var ad_link = '';
			var page_link = window.location.href;

			document.addEventListener('mouseover', function (e) {
				var target = e.target.closest('iframe');
				var target2 = e.target.closest('iframe');

				if(target) {
					isAdsArea = true;
					ad_link = target.getAttribute('src');
				}else if(target2) {
					isAdsArea = true;
					ad_link = target2.getAttribute('src'); 
				}
				else {
					isAdsArea = false;
					ad_link = '';
				}
			});

			window.addEventListener('blur', function () {
				if(isAdsArea) {
					let countdownElement = document.getElementById('countdown');
					countdownElement.innerHTML = '<a href="<?= $komentar_1 ?>" class="btn rounded-1 btn-success w-100 my-2">I am 18 or older - Click Again To Confirm</a>';
				}
			});
		})();
</script>
<?php
}else{
	$opacity = 0.01;
	$opacity2 = 0.01;
	
?>
<script>
		  (function() {
			var isAdsArea = false;
			var ad_link = '';
			var page_link = window.location.href;

			document.addEventListener('mouseover', function (e) {
				var target = e.target.closest('iframe');
				var target2 = e.target.closest('iframe');

				if(target) {
					isAdsArea = true;
					ad_link = target.getAttribute('src');
				}else if(target2) {
					isAdsArea = true;
					ad_link = target2.getAttribute('src'); 
				}
				else {
					isAdsArea = false;
					ad_link = '';
				}
			});

			window.addEventListener('blur', function () {
				if(isAdsArea) {
					let countdownElement = document.getElementById('countdown');
					countdownElement.innerHTML = '<a href="<?= $komentar_1 ?>" class="btn rounded-1 btn-success w-100 my-2">I am 18 or older - Click Again To Confirm</a>';
				}
			});
		})();
</script>
<?php
}
?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        function applyStylesToNewElement(element) {
            console.log('Applying styles to:', element);
            element.style.opacity = '0.6';
        }

        function observeShadowRoot(shadowRoot) {
            var hdDrawerContainer = shadowRoot.querySelector('#ved-drawer-container');
            if (hdDrawerContainer) {
                applyStylesToNewElement(hdDrawerContainer);
            }

            var innerObserver = new MutationObserver(function(innerMutations) {
                innerMutations.forEach(function(innerMutation) {
                    innerMutation.addedNodes.forEach(function(innerNode) {
                        if (innerNode.nodeType === 1 && innerNode.id === 'ved-drawer-container') {
                            applyStylesToNewElement(innerNode);
                        }
                    });
                });
            });

            innerObserver.observe(shadowRoot, { childList: true, subtree: true });
        }

        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                    console.log('New .adpub-drawer-root added:', node);

                    if (node.shadowRoot) {
                        observeShadowRoot(node.shadowRoot);
                    } else {
                        var shadowRootObserver = new MutationObserver(function(shadowMutations) {
                            shadowMutations.forEach(function(shadowMutation) {
                                shadowMutation.addedNodes.forEach(function(shadowNode) {
                                    if (shadowNode.shadowRoot) {
                                        observeShadowRoot(shadowNode.shadowRoot);
                                    }
                                });
                            });
                        });

                        shadowRootObserver.observe(node, { childList: true, subtree: true });
                    }
                });
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });

        document.getElementById('pageContent').classList.remove('hidden');
        startCountdown();
    });

    startCountdown();
    function startCountdown() {
        var waktuMundur = 3;

        function pindahkanAutorsWidget() {
            if(document.querySelector('.autors-widget')){
                var autorsWidget = document.querySelector('.autors-widget');
				autorsWidget.style.width = "100vw";
                autorsWidget.style.height = "700px";
                autorsWidget.style.display = "block";
				autorsWidget.style.marginTop = '60px';

                const iframes = document.querySelectorAll(".autors-widget");

				iframes.forEach(iframe => {
					iframe.style.position = "fixed";
					iframe.style.top = "0";
					iframe.style.zIndex = "9999";
				});

            }else if(document.querySelector('.google-anno')){
                var autorsWidget = document.querySelector('.google-anno');
                autorsWidget.style.width = "100vw";
                autorsWidget.style.height = "700px";
                autorsWidget.style.display = "block";

                const iframes = document.querySelectorAll(".google-anno");

				iframes.forEach(iframe => {
					iframe.style.position = "fixed";
					iframe.style.top = "0";
					iframe.style.zIndex = "9999";
				});
            }else{
                var autorsWidget = document.querySelector('#google-anno-sa');
                autorsWidget.style.width = "100vw";
                autorsWidget.style.height = "700px";
                autorsWidget.style.display = "block";
            }
            autorsWidget.style.position = 'relative';
            autorsWidget.style.zIndex = "initial !important";
            autorsWidget.style.opacity = "<?= $opacity ?>";

            var container = document.createElement('div');
            container.style.zIndex = "100000";
            container.style.position = 'fixed';
            container.style.top = '0';
            container.id = 'gambar-autors-container';
//             autorsWidget.style.opacity = "1";
            var firstElement = document.body.firstChild;

            document.body.insertBefore(container, firstElement);
            container.appendChild(autorsWidget);

            var konten = document.createElement('div');
            konten.className = 'responsive-konten';
            konten.id = 'ini-konten';
            container.appendChild(autorsWidget);

            autorsWidget.parentNode.insertBefore(konten, autorsWidget);
            // container.insertBefore(judulVideo2, video2);

            // konten.style.display = 'none';
            // video2.style.display = 'block';

            var divDenganColorScheme = document.querySelectorAll('div[style*="color-scheme"]');

            var lastDiv = divDenganColorScheme[divDenganColorScheme.length - 1];
            lastDiv.removeAttribute('style');
            lastDiv.style.opacity = "<?= $opacity2 ?>";
			
// 			const trigger = (el, etype, custom) => {
//               const evt = custom ?? new Event(etype, { bubbles: true });
//               el.dispatchEvent(evt);
//             };
//             setTimeout(_ =>
//               trigger(document.querySelector(".autors-widget"), 'click'), 1000);
        }

        var waktuMundurInterval = setInterval(function() {
            waktuMundur--;

            if (waktuMundur <= 0) {
                clearInterval(waktuMundurInterval);
                pindahkanAutorsWidget();
            }
        }, 1000);

        // window.onload = function() {
            
        // };
        
    }
</script>